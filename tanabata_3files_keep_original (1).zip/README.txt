たなばたリトミック セット

パスワード：
7Tb@Rit!2026#Home

ファイル構成：
index.html ＝ パスワード入力・選択画面
normal.html ＝ 通常版そのまま
care.html ＝ 配慮版そのまま

使い方：
3つのファイルを同じ場所にアップロードしてください。
Vercelでは index.html が最初に開きます。
